#!/bin/bash

# Author : Vikram Singh

echo "Current Date: $(date)"

echo "Please enter for how many days you need the info?"
read TOTAL_DAYS
echo "Executing script for last $TOTAL_DAYS days"

cd $XXHSC_TOP/XXHSC_SOA/adf
echo "Current Directory for adf:"
pwd
file_list=$(find -name "*.ear" -mtime -$TOTAL_DAYS -ls)

if [ -z $file_list ]; then
echo "No file found"
else
find -name "*.ear" -mtime -$TOTAL_DAYS -ls
fi
cd $XXHSC_TOP/XXHSC_SOA/soa
echo "Current directory for soa:"
pwd
file_list1=$(find -name "*.jar" -mtime -$TOTAL_DAYS -ls)
if [ -z $file_list1 ]; then
echo "No file found"
else
find -name "*.jar" -mtime -$TOTAL_DAYS -ls
fi
