SET SERVEROUTPUT ON;
SET verify OFF;
     /*=============================================================================+
 	 |  File Name 	: GL_INTERFACE_04MAR2019_DataFix.sql					 		|
 	 |  Description : This script creates backup table as well as updates           |
	 |  	     	  gl_interface table                                            |
	 |  Creation Date : 04-Mar-2019													|
	 |  Created By	  : Nathaniel Vadde  											|
 	 +===============================================================================*/

CREATE TABLE  gl_interface_04MAR2019
AS 
SELECT * from gl_interface 
WHERE 1=1 
AND ledger_id = 2105
AND user_je_source_name = 'Financials India'
AND accounting_date >= to_date('01-JAN-2019', 'DD-MON-YYYY') 
AND accounting_date <= to_date('31-JAN-2019', 'DD-MON-YYYY') 
AND STATUS = 'EP01';

UPDATE gl_interface
SET accounting_date = to_date('28-FEB-2019', 'DD-MON-YYYY')
WHERE 1=1
AND ledger_id = 2105
AND user_je_source_name = 'Financials India'
AND accounting_date >= to_date('01-JAN-2019', 'DD-MON-YYYY') 
AND accounting_date <= to_date('31-JAN-2019', 'DD-MON-YYYY') 
AND STATUS = 'EP01';
/
