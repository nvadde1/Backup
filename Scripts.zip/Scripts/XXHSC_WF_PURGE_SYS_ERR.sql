SET SERVEROUTPUT ON;
SET verify OFF;
     /*===============================================================================+
 	 |  File Name 	: XXHSC_WF_PURGE_SYS_ERR.sql    						 		  |
 	 |  Description : This script is created to aborts old Sytem Error workflow items |
	 |  	          not associated with any Parent Item type                        |
	 |  Creation Date : 27-Nov-2018												      |
	 |  Created By	  : Nathaniel Vadde     										  |
 	 +================================================================================*/
DECLARE
  counter NUMBER; 
 
  CURSOR abort_wf
  IS
    SELECT item_key
    FROM wf_items
    WHERE item_type = 'WFERROR'
    AND end_date   IS NULL
    AND begin_date <= SYSDATE -30;
BEGIN
  counter := 1 ;
  FOR wf IN abort_wf
  LOOP
    BEGIN
      WF_ENGINE.AbortProcess('WFERROR', wf.item_key);
      counter   := counter + 1 ;
      IF counter > 1000 THEN
        counter := 1 ;
        COMMIT;
      END IF;
    END;
  END LOOP;
  COMMIT;
END;
/