SET SERVEROUTPUT ON;
SET verify OFF;
     /*===============================================================================+
 	 |  File Name 	: XXHSC_AFI_TAB_DATAFIX.sql    						 		      |
 	 |  Description : This script will replace tab space in afinumber 2018MSVBR01840  |
	 |  	          with null                                                       |
	 |  Creation Date : 08-Jan-2019												      |
	 |  Created By	  : Nathaniel Vadde     										  |
 	 +================================================================================*/
update XXHSC.XXHSC_AFI_SUMMARY_B
set afinumber= replace(afinumber, chr(9), '')
where afinumber like '2018MSVBR01840%'
;�
/