SET SERVEROUTPUT ON;
SET verify OFF;
     /*===============================================================================+
 	 |  File Name 	: XXHSC_AFI_TAB_DATA_FIX.sql    					 		      |
 	 |  Description : CHG0011726 - AFI 2018MSVBR01840 - Issue with an extra TAB       |
	 |  	          in Oracle for AFI Number                                        |
	 |                                                                                |
	 |  Creation Date : 08-Jan-2019												      |
	 |  Created By	  : Nathaniel Vadde     										  |
 	 +================================================================================*/
update XXHSC.XXHSC_AFI_SUMMARY_B
set afinumber= replace(afinumber, chr(9), '')
where afinumber like '2018MSVBR01840%'
;�
/