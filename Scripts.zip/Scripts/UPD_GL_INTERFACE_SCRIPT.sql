SET SERVEROUTPUT ON;
SET verify OFF;
     /*=============================================================================+
     |  File Name   : UPD_GL_INTERFACE_CHG0012186.sql                               |
     |  Description : This script creates backup table as well as updates           |
     |                gl_interface table                                            |
     |  Creation Date : 03-May-2019                                                 |
     +===============================================================================*/

--Backup Table Details
CREATE TABLE gl_interface_03JUN2019 AS
SELECT *
FROM apps.gl_interface
WHERE 1                 =1
AND ledger_id           = 2105
AND user_je_source_name = 'Financials India'
AND accounting_date    >= to_date('01-APR-2019', 'DD-MON-YYYY')
AND accounting_date    <= to_date('30-APR-2019', 'DD-MON-YYYY')
--AND STATUS              = 'EP01'
;
--Update Query
UPDATE gl_interface
SET accounting_date     = to_date('31-MAY-2019', 'DD-MON-YYYY')
WHERE 1                 =1
AND ledger_id           = 2105
AND user_je_source_name = 'Financials India'
AND accounting_date    >= to_date('01-APR-2019', 'DD-MON-YYYY')
AND accounting_date    <= to_date('30-APR-2019', 'DD-MON-YYYY')
--AND STATUS              = 'EP01'
;
/