PROMPT .
PROMPT ========================================================================================
/*
*   Disclaimer:-
*   Please run the script on TEST instance first, if satisfied then run on PRODUCTION Instance.
*   Oracle Corp is NOT responsible if directly run on PRODUCTION Instance without running on TEST instance.
*   This script is NOT a generic script, It is very scpecific for recommended/Problematic Sales Order.
*/
PROMPT ========================================================================================
PROMPT .
PROMPT .
SET SERVEROUTPUT ON SIZE 100000;
SET VERIFY OFF;

declare
l_file_val       VARCHAR2(60);
err_msg          VARCHAR2(240);
l_return_status  BOOLEAN := false;
v_org_id         NUMBER := -1;

cursor pending_receipts is
       select rcv.transaction_id
             ,oel.line_id
             ,oel.org_id
       from   rcv_transactions rcv,
              po_line_locations_all poll,
              oe_drop_ship_sources oed,
              oe_order_lines_all oel
       where  oel.source_type_code = 'EXTERNAL'
       and    nvl(oel.shipped_quantity,0) = 0
       and    oed.line_id = oel.line_id
       and    oed.line_location_id is not null
       and    poll.line_location_id = oed.line_location_id
       and    rcv.po_line_location_id = poll.line_location_id
       and    oel.flow_status_code= 'AWAITING_RECEIPT'
       and    rcv.TRANSACTION_TYPE = 'DELIVER'
       order by oel.org_id;

BEGIN
    oe_debug_pub.debug_on;
    oe_debug_pub.initialize;
    l_file_val := OE_DEBUG_PUB.Set_Debug_Mode('FILE');
    oe_Debug_pub.setdebuglevel(5);
    dbms_output.put_line('.');

    for all_lines in pending_receipts loop
      IF v_org_id<> all_lines.org_id
      THEN
         
         v_org_id := all_lines.org_id;
         DBMS_OUTPUT.put_line('  ..  Organization ID set is : '||v_org_id);
         OE_DEBUG_PUB.ADD( ' <1> ... Setting client info to '||v_org_id);
         fnd_client_info.set_org_context(to_char(v_org_id));
         
      END IF;
    
    
        l_return_status := OE_DS_PVT.DROPSHIPRECEIVE(all_lines.transaction_id,'PO');
        if l_return_status = true then
            DBMS_OUTPUT.PUT_LINE('  Script was successful for line id : '||all_lines.line_id);
            OE_DEBUG_PUB.ADD('   Script was successful for line id : '||all_lines.line_id);
            commit;
        else
            DBMS_OUTPUT.PUT_LINE('  Script was Un-successful for line id : '||all_lines.line_id);
            OE_DEBUG_PUB.ADD(' SRG   !!! Script was Un-successful for line id : '||all_lines.line_id);
            rollback;
        end if;
    end loop;
    DBMS_OUTPUT.PUT_LINE('.');
    dbms_output.put_line('..... Debug file name and path: '||OE_DEBUG_PUB.G_DIR||'/'||OE_DEBUG_PUB.G_FILE);
    DBMS_OUTPUT.PUT_LINE('.');
EXCEPTION
 WHEN OTHERS THEN
         ERR_MSG := 'ERROR :'||SQLERRM;
         DBMS_OUTPUT.PUT_LINE('ERROR: Pls Rollback.................');
         DBMS_OUTPUT.PUT_LINE(SQLERRM);
         OE_DEBUG_PUB.ADD(ERR_MSG);
END;
