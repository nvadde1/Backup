
SET SERVEROUTPUT ON;
SET verify OFF;
     /*=============================================================================+
 	 |  File Name 	: XXHSC_WF_DATAFIX_FOR_PURGING.sql						 		|
 	 |  Description : This script is created to fix the data and make it 			|
	 |  	available for purging. This script aborts old open workflow items, 		|
	 |  	notifications, activities and activity history. It also removes parent 	|
	 |  	references from orphan child workflow items to make those available 	|
	 |  	for purging.    														|
	 |  Creation Date : 15-Jun-2015													|
	 |  Created By	  : Malhar														|
 	 +===============================================================================*/
accept Days_Before prompt "Enter Days before: "
DECLARE

  CURSOR C1 IS
  -- Open PO Approval Workflow.
  -----------------------------
  SELECT item_type, item_key 
  FROM apps.wf_items 
  WHERE item_type='POAPPRV' 
  AND begin_date < sysdate - '&Days_Before' 
  AND end_date IS NULL
  UNION
  -- All child items for PO Approval workflow
  SELECT item_type, item_key 
  FROM apps.wf_items 
  WHERE (parent_item_type, parent_item_key) IN (
      SELECT item_type, item_key 
      FROM apps.wf_items 
      WHERE item_type='POAPPRV' 
      AND begin_date < sysdate - '&Days_Before')
  AND end_date IS NULL  
  UNION
  -- Open CreatePO Workflow
  -----------------------------
  SELECT item_type, item_key 
  FROM apps.wf_items 
  WHERE item_type='CREATEPO' 
  AND begin_date < sysdate - '&Days_Before' 
  AND end_date IS NULL
  UNION
  SELECT item_type, item_key 
  FROM apps.wf_items 
  WHERE (parent_item_type, parent_item_key) IN (
      SELECT item_type, item_key 
      FROM apps.wf_items 
      WHERE item_type='CREATEPO' 
      AND begin_date < sysdate - '&Days_Before' )
  AND end_date IS NULL
  UNION
  -- Agreement Authorization Workflow
  -----------------------------------
  SELECT item_type, item_key 
  FROM apps.wf_items 
  WHERE item_type='POAUTH' 
  AND begin_date < sysdate - '&Days_Before' 
  AND end_date IS NULL
  UNION
  -- All child items for Agreement Authorization Workflow
  SELECT item_type, item_key 
  FROM apps.wf_items 
  WHERE (parent_item_type, parent_item_key) IN (
      SELECT item_type, item_key 
      FROM apps.wf_items 
      WHERE item_type='POAUTH' 
      AND begin_date < sysdate - '&Days_Before' )
  AND end_date IS NULL
  UNION
  -- PO Change Request Workflow
  -----------------------------
  SELECT item_type, item_key 
  FROM apps.wf_items 
  WHERE item_type='POREQCHA' 
  AND begin_date < sysdate - '&Days_Before' 
  UNION
  -- All child items for PO Change Request Workflow
  SELECT item_type, item_key 
  FROM apps.wf_items 
  WHERE (parent_item_type, parent_item_key) IN (
      SELECT item_type, item_key 
      FROM apps.wf_items 
      WHERE item_type='POREQCHA' 
      AND begin_date < sysdate - '&Days_Before' )
  AND end_date IS NULL
  UNION
  -- Requisition Approval Workflow
  --------------------------------
  SELECT item_type, item_key 
  FROM apps.wf_items 
  WHERE item_type='REQAPPRV' 
  AND begin_date < sysdate - '&Days_Before' 
  AND end_date IS NULL
  UNION
  -- All child items for Requisition Approval Workflow
  SELECT item_type, item_key 
  FROM apps.wf_items 
  WHERE (parent_item_type, parent_item_key) IN (
      SELECT item_type, item_key 
      FROM apps.wf_items 
      WHERE item_type='REQAPPRV' 
      AND begin_date < sysdate - '&Days_Before' )
  AND end_date IS NULL
  UNION
  -- AP Card Payments Workflow
  --------------------------------
  SELECT item_type, item_key 
  FROM apps.wf_items 
  WHERE item_type='APCCARD' 
  AND begin_date < sysdate - '&Days_Before' 
  AND end_date IS NULL
  UNION
  -- All child items for AP Card Payments Workflow
  SELECT item_type, item_key 
  FROM apps.wf_items 
  WHERE (parent_item_type, parent_item_key) IN (
      SELECT item_type, item_key 
      FROM apps.wf_items 
      WHERE item_type='APCCARD' 
      AND begin_date < sysdate - '&Days_Before' )
  AND end_date IS NULL
  UNION
  -- AP Invoice Hold workflow
  --------------------------------
  SELECT item_type, item_key 
  FROM apps.wf_items 
  WHERE item_type='APINVHDN' 
  AND begin_date < sysdate - '&Days_Before' 
  AND end_date IS NULL
  UNION
  -- All child items for AP Invoice Hold workflow
  SELECT item_type, item_key 
  FROM apps.wf_items 
  WHERE (parent_item_type, parent_item_key) IN (
      SELECT item_type, item_key 
      FROM apps.wf_items 
      WHERE item_type='APINVHDN' 
      AND begin_date < sysdate - '&Days_Before' )
  AND end_date IS NULL  
  UNION
    -- Requisition account Generator workflow
  --------------------------------
  SELECT item_type, item_key 
  FROM apps.wf_items 
  WHERE item_type='POWFRQAG' 
  AND begin_date < sysdate - '&Days_Before' 
  AND end_date IS NULL
  UNION
  -- All child items for Requisition account Generator workflow
  SELECT item_type, item_key 
  FROM apps.wf_items 
  WHERE (parent_item_type, parent_item_key) IN (
      SELECT item_type, item_key 
      FROM apps.wf_items 
      WHERE item_type='POWFRQAG' 
      AND begin_date < sysdate - '&Days_Before' )
  AND end_date IS NULL  
  UNION
    -- Service fulfilment Workflow
  --------------------------------
  SELECT item_type, item_key 
  FROM apps.wf_items 
  WHERE item_type='XDPWFSTD' 
  AND begin_date < sysdate - '&Days_Before' 
  AND end_date IS NULL
  UNION
  -- All child items for Service fulfilment Workflow
  SELECT item_type, item_key 
  FROM apps.wf_items 
  WHERE (parent_item_type, parent_item_key) IN (
      SELECT item_type, item_key 
      FROM apps.wf_items 
      WHERE item_type='XDPWFSTD' 
      AND begin_date < sysdate - '&Days_Before' )
  AND end_date IS NULL  
  UNION
   -- Workflow mailer test
  --------------------------------
  SELECT item_type, item_key 
  FROM apps.wf_items 
  WHERE item_type='WFTESTS' 
  AND begin_date < sysdate - '&Days_Before' 
  AND end_date IS NULL
  UNION
  -- All child items for Workflow mailer test
  SELECT item_type, item_key 
  FROM apps.wf_items 
  WHERE (parent_item_type, parent_item_key) IN (
      SELECT item_type, item_key 
      FROM apps.wf_items 
      WHERE item_type='WFTESTS' 
      AND begin_date < sysdate - '&Days_Before' )
  AND end_date IS NULL  
  UNION
    -- PO Account Generator workflow
  --------------------------------
  SELECT item_type, item_key 
  FROM apps.wf_items 
  WHERE item_type='POWFPOAG' 
  AND begin_date < sysdate - '&Days_Before' 
  AND end_date IS NULL
  UNION
  -- All child items for PO Account Generator workflow
  SELECT item_type, item_key 
  FROM apps.wf_items 
  WHERE (parent_item_type, parent_item_key) IN (
      SELECT item_type, item_key 
      FROM apps.wf_items 
      WHERE item_type='POWFPOAG' 
      AND begin_date < sysdate - '&Days_Before' )
  AND end_date IS NULL  
  UNION
    -- Expense Receipt Workflow
  --------------------------------
  SELECT item_type, item_key 
  FROM apps.wf_items 
  WHERE item_type='APWRECPT' 
  AND begin_date < sysdate - '&Days_Before' 
  AND end_date IS NULL
  UNION
  -- All child items for Expense Receipt Workflow
  SELECT item_type, item_key 
  FROM apps.wf_items 
  WHERE (parent_item_type, parent_item_key) IN (
      SELECT item_type, item_key 
      FROM apps.wf_items 
      WHERE item_type='APWRECPT' 
      AND begin_date < sysdate - '&Days_Before' )
  AND end_date IS NULL  
  UNION
    -- PO Receipt confirmation workflow
  --------------------------------
  SELECT item_type, item_key 
  FROM apps.wf_items 
  WHERE item_type='PORCPT' 
  AND begin_date < sysdate - '&Days_Before' 
  AND end_date IS NULL
  UNION
  -- All child items for PO Receipt confirmation workflow
  SELECT item_type, item_key 
  FROM apps.wf_items 
  WHERE (parent_item_type, parent_item_key) IN (
      SELECT item_type, item_key 
      FROM apps.wf_items 
      WHERE item_type='PORCPT' 
      AND begin_date < sysdate - '&Days_Before' )
  AND end_date IS NULL  
  UNION
    -- PO Change request workflow
  --------------------------------
  SELECT item_type, item_key 
  FROM apps.wf_items 
  WHERE item_type='PORPOCHA' 
  AND begin_date < sysdate - '&Days_Before' 
  AND end_date IS NULL
  UNION
  -- All child items for PO Change request workflow
  SELECT item_type, item_key 
  FROM apps.wf_items 
  WHERE (parent_item_type, parent_item_key) IN (
      SELECT item_type, item_key 
      FROM apps.wf_items 
      WHERE item_type='PORPOCHA' 
      AND begin_date < sysdate - '&Days_Before' )
  AND end_date IS NULL  
  UNION
    -- OPM Workflow
  --------------------------------
  SELECT item_type, item_key 
  FROM apps.wf_items 
  WHERE item_type='GMDQMSMC' 
  AND begin_date < sysdate - '&Days_Before' 
  AND end_date IS NULL
  UNION
  -- All child items for OPM Workflow
  SELECT item_type, item_key 
  FROM apps.wf_items 
  WHERE (parent_item_type, parent_item_key) IN (
      SELECT item_type, item_key 
      FROM apps.wf_items 
      WHERE item_type='GMDQMSMC' 
      AND begin_date < sysdate - '&Days_Before' )
  AND end_date IS NULL  
  UNION
    -- Employee time sheets workflow
  --------------------------------
  SELECT item_type, item_key 
  FROM apps.wf_items 
  WHERE item_type='HXCEMP' 
  AND begin_date < sysdate - '&Days_Before' 
  AND end_date IS NULL
  UNION
  -- All child items for Employee time sheets workflow
  SELECT item_type, item_key 
  FROM apps.wf_items 
  WHERE (parent_item_type, parent_item_key) IN (
      SELECT item_type, item_key 
      FROM apps.wf_items 
      WHERE item_type='HXCEMP' 
      AND begin_date < sysdate - '&Days_Before' )
  AND end_date IS NULL  
  UNION  
   /*
      -- OM Workflows  -- Comment this part after testing in HSCPAT
  --------------------------------
  SELECT item_type, item_key 
  FROM apps.wf_items 
  WHERE item_type='OEOH' 
  AND begin_date < sysdate - '&Days_Before' 
  AND end_date IS NULL
  UNION
  SELECT item_type, item_key 
  FROM apps.wf_items 
  WHERE (parent_item_type, parent_item_key) IN (
      SELECT item_type, item_key 
      FROM apps.wf_items 
      WHERE item_type='OEOH' 
      AND begin_date < sysdate - '&Days_Before' )
  AND end_date IS NULL  
  UNION
  SELECT item_type, item_key 
  FROM apps.wf_items 
  WHERE item_type='OEOL' 
  AND begin_date < sysdate - '&Days_Before' 
  AND end_date IS NULL
  UNION
  SELECT item_type, item_key 
  FROM apps.wf_items 
  WHERE (parent_item_type, parent_item_key) IN (
      SELECT item_type, item_key 
      FROM apps.wf_items 
      WHERE item_type='OEOL' 
      AND begin_date < sysdate - '&Days_Before' )
  AND end_date IS NULL  
  UNION  
  SELECT item_type, item_key 
  FROM apps.wf_items 
  WHERE item_type='OEBH' 
  AND begin_date < sysdate - '&Days_Before' 
  AND end_date IS NULL
  UNION
  SELECT item_type, item_key 
  FROM apps.wf_items 
  WHERE (parent_item_type, parent_item_key) IN (
      SELECT item_type, item_key 
      FROM apps.wf_items 
      WHERE item_type='OEBH' 
      AND begin_date < sysdate - '&Days_Before' )
  AND end_date IS NULL  
  UNION
    SELECT item_type, item_key 
  FROM apps.wf_items 
  WHERE item_type='OENH' 
  AND begin_date < sysdate - '&Days_Before' 
  AND end_date IS NULL
  UNION
  SELECT item_type, item_key 
  FROM apps.wf_items 
  WHERE (parent_item_type, parent_item_key) IN (
      SELECT item_type, item_key 
      FROM apps.wf_items 
      WHERE item_type='OENH' 
      AND begin_date < sysdate - '&Days_Before' )
  AND end_date IS NULL  
  UNION
  */
    -- OAM Workflow event 
  --------------------------------
  SELECT item_type, item_key 
  FROM apps.wf_items 
  WHERE item_type='OAM_BE' 
  AND begin_date < sysdate - '&Days_Before' 
  AND end_date IS NULL
  UNION
  -- All child items for OAM Workflow
  SELECT item_type, item_key 
  FROM apps.wf_items 
  WHERE (parent_item_type, parent_item_key) IN (
      SELECT item_type, item_key 
      FROM apps.wf_items 
      WHERE item_type='OAM_BE' 
      AND begin_date < sysdate - '&Days_Before' )
  AND end_date IS NULL  
    UNION
    -- OAM Workflow event 
  --------------------------------
  SELECT item_type, item_key 
  FROM apps.wf_items 
  WHERE item_type='EAMWRAP' 
  AND begin_date < sysdate - '&Days_Before' 
  AND end_date IS NULL
  UNION
  -- All child items for OAM Workflow
  SELECT item_type, item_key 
  FROM apps.wf_items 
  WHERE (parent_item_type, parent_item_key) IN (
      SELECT item_type, item_key 
      FROM apps.wf_items 
      WHERE item_type='EAMWRAP' 
      AND begin_date < sysdate - '&Days_Before' )
  AND end_date IS NULL  
  UNION
  -- Error WorkflowS 
  -------------------------------- 
  SELECT item_type, item_key 
  FROM apps.wf_items 
  WHERE item_type='WFERROR' 
  AND begin_date < sysdate - '&Days_Before' 
  AND end_date IS NULL
    UNION
  SELECT item_type, item_key 
  FROM apps.wf_items 
  WHERE item_type='OMERROR' 
  AND begin_date < sysdate - '&Days_Before' 
  AND end_date IS NULL
      UNION
  SELECT item_type, item_key 
  FROM apps.wf_items 
  WHERE item_type='POERROR' 
  AND begin_date < sysdate - '&Days_Before' 
  AND end_date IS NULL
; 
  
BEGIN

 IF ('&Days_Before' > 299) THEN

  -- PO Error Workflow
  UPDATE apps.wf_items 
  SET parent_item_type =NULL,
    parent_item_key =NULL
  WHERE item_type='POERROR' 
  AND begin_date < sysdate - '&Days_Before' 
  AND end_date IS NOT NULL;
  
   -- Generic Error Workflow
  UPDATE apps.wf_items 
  SET parent_item_type =NULL,
    parent_item_key =NULL
  WHERE item_type='WFERROR' 
  AND begin_date < sysdate - '&Days_Before' 
  AND end_date IS NOT NULL;
  
   -- OM Error Workflow
  UPDATE apps.wf_items 
  SET parent_item_type =NULL,
    parent_item_key =NULL
  WHERE item_type='OMERROR' 
  AND begin_date < sysdate - '&Days_Before' 
  AND end_date IS NOT NULL;

    FOR i IN C1
    LOOP
    update wf_notifications set 
      end_date = sysdate - '&Days_Before'
    where group_id in 
      (select notification_id
      from wf_item_activity_statuses
      where item_type = i.item_type
      and item_key = i.item_key
      union
      select notification_id
      from wf_item_activity_statuses_h
      where item_type = i.item_type
      and item_key = i.item_key
	  );

    update wf_items set 
      end_date = sysdate - '&Days_Before'
      where item_type = i.item_type
      and item_key = i.item_key
	;

    update wf_item_activity_statuses set 
      end_date = sysdate - '&Days_Before'
      where item_type = i.item_type
      and item_key = i.item_key
	;

    update wf_item_activity_statuses_h set 
      end_date = sysdate - '&Days_Before'
      where item_type = i.item_type
      and item_key = i.item_key
	;
  
  END LOOP;

  dbms_output.put_line('Workflow Update Completed. Please run purge program ');
 END IF;
EXCEPTION
  WHEN OTHERS THEN
  dbms_output.put_line('Error - '||SQLERRM);
END;
/